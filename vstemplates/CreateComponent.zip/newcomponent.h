#pragma once

#include <nap/component.h>

namespace nap
{
	class $fileinputname$Instance;

	/**
	 *	$fileinputname$
	 */
	class $fileinputname$ : public Component
	{
		RTTI_ENABLE(Component)
		DECLARE_COMPONENT($fileinputname$, $fileinputname$Instance)
	public:
	};


	/**
	 * $fileinputname$Instance	
	 */
	class $fileinputname$Instance : public ComponentInstance
	{
		RTTI_ENABLE(ComponentInstance)
	public:
		$fileinputname$Instance(EntityInstance& entity, Component& resource) :
			ComponentInstance(entity, resource)									{ }
	};
}
