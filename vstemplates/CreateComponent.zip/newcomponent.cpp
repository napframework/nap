#include "$fileinputname$.h"

// External Includes
#include <nap/entity.h>

RTTI_BEGIN_CLASS(nap::$fileinputname$)
RTTI_END_CLASS

RTTI_BEGIN_CLASS_NO_DEFAULT_CONSTRUCTOR(nap::$fileinputname$Instance)
	RTTI_CONSTRUCTOR(nap::EntityInstance&, nap::Component&)
RTTI_END_CLASS