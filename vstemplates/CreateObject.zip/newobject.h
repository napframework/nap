#pragma once

// External Includes
#include <rtti/rttiobject.h>

namespace nap
{
	/**
	 * $fileinputname$
	 */
	class $fileinputname$ : public rtti::RTTIObject
	{
		RTTI_ENABLE(rtti::RTTIObject)
	public:
		virtual ~$fileinputname$();

		/**
		* Initialize this object after de-serialization
		* @param errorState contains the error message when initialization fails
		*/
		virtual bool init(utility::ErrorState& errorState) override;
	};
}
